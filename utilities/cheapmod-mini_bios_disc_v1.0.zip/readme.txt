
Cheapmod Mini BIOS Disc - v1.0.0 README
================================================================


DISCLAIMER:
=======================================
This software is provided as-is, with no warranties implied!

Use this software at your own risk!

Visit SylverReZ's website at: https://m4x1mumrez87.neocities.org


Overview:
=======================================
The BIOS disc provides a combination of supported custom BIOSes onto
one single bootable DVD. This release includes:

 - Evo-X dashboard interface.
 - Latest Cerbios, Xecuter 2 and Evo-X M8+ BIOS.
 - Support for the 49LF020 flash chip ONLY.
 - Support for ALL console revisions (V1.0 - V1.6/B).

I would like to point out that the disc can only re-flash the
Cheapmod Mini and a no. of cheapmods that have a GENUINE 49LF020
chip pre-installed.

If the chip is a fake, then the process will fail automatically.


Burning the DVD:
=======================================

To reduce the strain of the laser, I strongly recommend using
high-quality DVD-R media such as Verbatim.


Burn the image using any application that is capable of writing ISOs,
(i.e., ImgBurn/Nero/cdrecord/DiscJuggler).


Ensure that the writing speed is as low if possible, 4x is recommended.


Navigation:
=======================================
D-PAD (Up/Down): Navigating through the menus.
A: Select item.
B: Go back.


Shoutouts:
=======================================
Team Resurgent for amazing projects such as LPC-Mangler, Pandora
and CerbiosTool.

Team Cerbios for Cerbios.

Team Xecuter for Xecuter 2 BIOS.

Evo-X Team for Evo-X and dashboard.

ModzvilleUSA for his great modchip installs.

Dobart M. for providing the v1.6 cheapmod install diagrams.

DarkDestiny for OGXbox Installer and OGXbox Cerbios Flasher discs.

Kekule for R3DUX and Jafar.

XBOX-SCENE for their amazing contributions to the community.

And you for supporting this project!

